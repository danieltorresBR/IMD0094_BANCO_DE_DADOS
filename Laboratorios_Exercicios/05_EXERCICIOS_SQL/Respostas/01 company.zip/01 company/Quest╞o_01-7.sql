select distinct employee.fname, employee.minit, employee.lname 
from company.department join company.employee on department.mgr_ssn = employee.ssn,
	 company.dependent
where not exists (
	select * 
    from company.dependent 
    where dependent.essn = employee.ssn)
order by employee.fname;